import logo from './logo.svg';
import './App.css';
import {useState} from 'react'

function App() {

let [laptops,setLaptops] = useState([]);

let [iphones,setIphones] = useState([]);

  let getLaptops = async ()=>{
    let reqOptions = {
      method:"GET"
    }


    let JOSONData = await fetch("http://localhost:2345/laptops", reqOptions);

    let JSOData = await JOSONData.json();


    setLaptops(JSOData);
    console.log(JSOData);
  }
    let getIphones = async ()=>{

      let reqOptions = {
        method:"GET"
      }

      let JSONData = await fetch("http://localhost:2345/iphones",reqOptions);

      let JSOData = await JSONData.json();

      setIphones(JSOData);
      console.log(JSOData);
    }


  
  return (
    <div className="App">
      <button onClick={()=>{
        getLaptops();
      }}>Get Laptops</button>

      <button onClick={()=>{
        getIphones();
      }}>Get Iphones</button>


      {laptops.map((ele,i)=>{
        return <h2 key={i}>{ele}</h2>
      })}

      {iphones.map((ele,i)=>{
        return <h2 key={i}>{ele}</h2>
      })}
    </div>
  );
}

export default App;
