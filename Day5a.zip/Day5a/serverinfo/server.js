const express = require("express");

const cors =require("cors");

let app = express();
app.use(cors());




app.get("/laptops",(req,res)=>{

    let laptops =["Asus","Dell","Hp","Lenovo","Mac"]


    res.json(laptops);
})

app.get("/iphones",(req,res)=>{
    let iph = ["iphone 6s","iphone x","iphone 11","iphone 15pro"]

    res.json(iph);
})


app.listen(2345,()=>{
    console.log('listen to port 2345')
})